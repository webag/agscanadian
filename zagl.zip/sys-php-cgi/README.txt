Hostland remark:
You can remove directory sys-php-cgi (and all files inside it) after switching php from CGI to module mode in hosting panel

Hostland primechanie:
Vi mozhete udalit vsu papku sys-php-cgi i vse ee soderzhimoe posle perekluchenia php iz rezhima CGI v rezhim php modul v paneli upravlenia hostingom
